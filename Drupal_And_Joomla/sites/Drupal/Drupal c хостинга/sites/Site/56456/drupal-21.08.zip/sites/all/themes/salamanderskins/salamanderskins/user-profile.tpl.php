<div class="profile">
  <div class="profile-left"><?php print $profile_photo; ?><?php print $user_actions; ?><?php print $profile_region; ?></div>
  <div class="profile-right">
    <?php if ($profile_datebridth): ?>
    <div class="profile-group">
      <div class="profile-group-label"><?php print $variables['display_name']; ?><?php if (node_access('update', $profile)) print l('Редактировать', "user/$account->uid/profile/profile", array('fragment' => 'tabset-tab-2')); ?></div>
      <div class="profile-group-content">
        <table>
          <?php if ($profile_datebridth): ?><tr><td class="field-label">День рождения</td><td><?php print $profile_datebridth; ?></td></tr><?php endif; ?>
        </table>
      </div>
    </div>
    <?php endif; ?>

    <?php if ($profile_phone || $profile_icq): ?>
    <div class="profile-group">
      <div class="profile-group-label">Контактные данные<?php if (node_access('update', $profile)) print l('Редактировать', "user/$account->uid/profile/profile", array('fragment' => 'tabset-tab-4')); ?></div>
      <div class="profile-group-content">
        <table>
          <?php if ($profile_phone): ?><tr><td class="field-label">Телефон</td><td><?php print $profile_phone; ?></td></tr><?php endif; ?>
          <?php if ($profile_icq): ?><td class="field-label">ICQ</td><td><?php print $profile_icq; ?></td></tr><?php endif; ?>
        </table>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

