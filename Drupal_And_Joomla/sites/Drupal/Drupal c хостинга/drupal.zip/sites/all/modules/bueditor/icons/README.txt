
All icons in this directory(not including subdirectories) will be avaliable for
editors that identify this directory as icon path.
In editor settings specify icon path as:
%BUEDITOR/icons.

Do not put your custom icons here because:
  - They may get lost when you update the module
  - They won't be included in editor import/export operations

Instead, store all custom and default icons in a new directory under your files path.
Then in editor settings specify icon path as:
%FILES/custom-icon-path