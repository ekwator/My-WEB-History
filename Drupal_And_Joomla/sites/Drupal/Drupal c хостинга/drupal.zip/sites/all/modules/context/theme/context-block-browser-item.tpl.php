<div id='context-block-addable-<?php print $bid ?>' class='context-block-item context-block-addable clear-block'>
  <span class='icon'></span>
  <?php print $info ?>
</div>
