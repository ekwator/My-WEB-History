<?php

/**
 * @file
 * Definition of Drupal\Core\Database\Driver\mysql\Truncate
 */

namespace Drupal\Core\Database\Driver\mysql;

use Drupal\Core\Database\Query\Truncate as QueryTruncate;

class Truncate extends QueryTruncate { }
