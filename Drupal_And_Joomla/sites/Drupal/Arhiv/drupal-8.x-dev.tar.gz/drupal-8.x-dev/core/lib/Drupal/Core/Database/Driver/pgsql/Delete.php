<?php

/**
 * @file
 * Definition of Drupal\Core\Database\Driver\pgsql\Delete
 */

namespace Drupal\Core\Database\Driver\pgsql;

use Drupal\Core\Database\Query\Delete as QueryDelete;

class Delete extends QueryDelete { }
