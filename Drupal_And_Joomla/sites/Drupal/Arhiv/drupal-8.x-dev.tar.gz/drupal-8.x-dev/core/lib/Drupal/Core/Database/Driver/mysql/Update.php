<?php

/**
 * @file
 * Definition of Drupal\Core\Database\Driver\mysql\Update
 */

namespace Drupal\Core\Database\Driver\mysql;

use Drupal\Core\Database\Query\Update as QueryUpdate;

class Update extends QueryUpdate { }
