<?php

/**
 * @file
 * Definition of Drupal\Core\Database\Driver\pgsql\Transaction
 */

namespace Drupal\Core\Database\Driver\pgsql;

use Drupal\Core\Database\Transaction as DatabaseTransaction;

class Transaction extends DatabaseTransaction { }
