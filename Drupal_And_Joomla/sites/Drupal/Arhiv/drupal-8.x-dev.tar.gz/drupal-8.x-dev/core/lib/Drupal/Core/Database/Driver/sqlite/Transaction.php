<?php

/**
 * @file
 * Definition of Drupal\Core\Database\Driver\sqlite\Transaction
 */

namespace Drupal\Core\Database\Driver\sqlite;

use Drupal\Core\Database\Transaction as DatabaseTransaction;

class Transaction extends DatabaseTransaction { }
