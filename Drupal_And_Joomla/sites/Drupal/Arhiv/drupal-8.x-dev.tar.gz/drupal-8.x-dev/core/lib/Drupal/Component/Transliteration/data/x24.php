<?php

/**
 * @file
 * Generic transliteration data for the PHPTransliteration class.
 */

$base = array(
  0x00 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x10 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x20 => '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x30 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x40 => '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL,
  0x50 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x60 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x70 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x80 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x90 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xA0 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xB0 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xC0 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xD0 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xE0 => '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL,
  0xF0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
);
