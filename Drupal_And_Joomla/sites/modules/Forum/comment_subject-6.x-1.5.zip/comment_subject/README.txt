$Id: README.txt,v 1.2.4.1 2009/11/19 07:41:13 sinasalek Exp $

Description
------------------
  Provides a default comment subject: 'Re: [parent comment/node title]'.
  Comment subject is derived from the node title, or the comment that the
  new comment is a reply to. If the parent already starts with 're:', it is
  not added a second time.

  Users can still edit the comment subject to their liking if comment 
  titles are enabled in the comment settings
  
Author
-----------------
Aldo Hoeben <aldo AT hoeben DOT net>