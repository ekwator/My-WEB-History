NOTE: Please don't rip the example smileys and use them without this module.
      Steven Wittens spent quite some time creating those little buggers.
