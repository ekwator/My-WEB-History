Description
------

This is a simple smiley-filter that allows the easy use of graphical smileys (or 'emoticons') on a Drupal site. It comes with a set of example smileys, but you can define an unlimited amount of custom smileys as well.

You can add your own Smileys by importing ready to use packages available on the internet (e.g. phpBB emoticon "pak"s and Adium Emoticon packs). Extract them into FILES_DIRECTORY/smileys (usually sites/default/files/smileys) folder and import using the "Smileys Import" module.

Read corresponding text files for other topics.

NOTE: Please don't rip the Example and Roving smileys and use them without this module. Their creators spent quite some time creating those little buggers for dedicated use with the smileys module.


Authors
------

Steven Wittens <unconed@drupal.org>, Gurpartap Singh <http://drupal.org/user/41470/contact>