<?php
// $Id: views-bonus-panels-threecol-term.tpl.php,v 1.1 2009/01/03 04:50:45 neclimdul Exp $
/**
 * @file
 * Three column term grouped rendering template.
 */

panels_load_include('display-render');
print panels_print_layout($panel_name, $content);
