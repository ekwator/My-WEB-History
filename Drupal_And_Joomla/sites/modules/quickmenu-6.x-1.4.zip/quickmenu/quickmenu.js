$(document).ready( function() { $('.quick_menu_select').change( function() { window.location=$(this).val() } ); } );
