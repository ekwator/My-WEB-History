<?php
// $Id: views-nivo-slider-view-nivo-sliderfields.tpl.php,v 1.1.2.1 2010/04/12 19:31:10 pedrofaria Exp $
?>
<?php print $content ?>

