<?php
// $Id: calendar-span-week.tpl.php,v 1.1.2.1 2010/09/11 05:17:51 darrick Exp $
/**
 * @file
 * Template to display a view as a calendar week.
 * 
 * @see template_preprocess_calendar_week.
 *
 * $day_names: An array of the day of week names for the table header.
 * $rows: The rendered data for this week.
 * 
 * For each day of the week, you have:
 * $rows['date'] - the date for this day, formatted as YYYY-MM-DD.
 * $rows['datebox'] - the formatted datebox for this day.
 * $rows['empty'] - empty text for this day, if no items were found.
 * $rows['all_day'] - an array of formatted all day items.
 * $rows['items'] - an array of timed items for the day.
 * $rows['items'][$time_period]['hour'] - the formatted hour for a time period.
 * $rows['items'][$time_period]['ampm'] - the formatted ampm value, if any for a time period.
 * $rows['items'][$time_period]['values'] - An array of formatted items for a time period.
 * 
 * $view: The view.
 * $min_date_formatted: The minimum date for this calendar in the format YYYY-MM-DD HH:MM:SS.
 * $max_date_formatted: The maximum date for this calendar in the format YYYY-MM-DD HH:MM:SS.
 * 
 */
//dsm('Display: '. $display_type .': '. $min_date_formatted .' to '. $max_date_formatted);
//dsm($rows);
/*
dsm($items);
dsm($pretty_times);
dsm($columns);
dsm($rows);

 */
$grid_width=734;
$time_cell_width=40;
$day_cell_width=intval(($grid_width-$time_cell_width)/7);
$day_height=40;

?>

<style type="text/css">

.calendar-span-cell-item {
  background-color: white;
  overflow: hidden;
  position: absolute;
  width: 100%;
}

.calendar-calendar td.calendar-free-block:hover {
  cursor:pointer;
  background-color: blue;
}
.calendar-calendar td.calendar-free-block.o:hover {
  cursor: default;
  background-color: #FFFFFF;
}

.calendar-calendar div.calendar-free-block {
  background: transparent;
}
.schedule-container {
  position: relative;
  height: <?php print $day_height+$grid_height; ?>px;
  width: <?php print $grid_width; ?>px;
  background-color: #ffffcc;
  border-bottom: .3em solid #444;
}
.schedule-cell {
}
.schedule-agenda-hour {
  border-bottom: .3em solid #444;
  text-align: left;
}

.schedule-week {
  border-left: .3em solid #444;
  height: 100%;
}

.days {
  position: absolute;
}

</style>

<div class="calendar-calendar"><div class="week-view">
<table>



  <tbody>
    <tr>
<td>
<div class="schedule-container">

  <div style="position: absolute; top: 0; left: 0; width: <?php print $grid_width; ?>px;"> 
    <?php foreach ($pretty_times as $time): ?>
    <div class="schedule-agenda-hour" style="position:absolute; top: <?php print $time['top']+$day_height; ?>px; width: <?php print $grid_width; ?>px; height: <?php print $time['span']; ?>px;">
        <span class="calendar-hour"><?php print $time['hour']; ?></span>
        <span class="calendar-ampm"><?php print $time['ampm']; ?></span>
      </div>
    <?php endforeach; ?>  
  </div>
    
    <?php foreach ($items as $day => $times): ?>
    <div class="schedule-week" style="position: absolute; left: <?php print ($day)*$day_cell_width+$time_cell_width; ?>px; width: <?php print $day_cell_width; ?>px;"> 
    <div class="<?php print $day_names[$day]['class']; ?>" style="position: absolute; top: 0; height: <?php print $day_height; ?>px;"> 
          <?php print $day_names[$day]['data']; ?>
        </div>
        <?php foreach ($times as $time => $item): ?>
           <div class="calendar-span-cell<?php print isset($item['data']) ? "-item" : "-empty"; ?> " style="top: <?php print $item['total']+$day_height; ?>px; height: <?php print $item['span']; ?>px;">
              <?php print $item['data'] ; ?> 
</div>
        <?php endforeach; ?>
      </div>
    <?php endforeach; ?>
</div>
</td></tr></tbody></table>
</div>
</div>
