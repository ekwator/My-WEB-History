<?php
// $Id: calendar-span-day.tpl.php,v 1.1.2.2 2010/09/15 00:48:39 darrick Exp $
/**
 * @file
 * Template to display a view as a calendar day, grouped by time
 * and optionally organized into columns by a field value.
 * 
 * @see template_preprocess_calendar_day.
 *
 * $rows: The rendered data for this day.
 * $rows['date'] - the date for this day, formatted as YYYY-MM-DD.
 * $rows['datebox'] - the formatted datebox for this day.
 * $rows['empty'] - empty text for this day, if no items were found.
 * $rows['all_day'] - an array of formatted all day items.
 * $rows['items'] - an array of timed items for the day.
 * $rows['items'][$time_period]['hour'] - the formatted hour for a time period.
 * $rows['items'][$time_period]['ampm'] - the formatted ampm value, if any for a time period.
 * $rows['items'][$time_period][$column]['values'] - An array of formatted 
 *   items for a time period and field column.
 * 
 * $view: The view.
 * $columns: an array of column names.
 * $min_date_formatted: The minimum date for this calendar in the format YYYY-MM-DD HH:MM:SS.
 * $max_date_formatted: The maximum date for this calendar in the format YYYY-MM-DD HH:MM:SS.
 * 
 * The width of the columns is dynamically set using <col></col> 
 * based on the number of columns presented. The values passed in will
 * work to set the 'hour' column to 10% and split the remaining columns 
 * evenly over the remaining 90% of the table.
 */
//dsm('Display: '. $display_type .': '. $min_date_formatted .' to '. $max_date_formatted);
//dsm($rows);
$time_cell_width=150;
$day_cell_width=intval(($grid_width-$time_cell_width)/7);
$row_height=40;


$grid_width=$time_cell_width + count($pretty_times)*60;

?>
<style type="text/css">

.tableBorder {
    background-color: #36648B;
}


.scheduleTable {
    border-collapse: separate;
  padding: 0em;
  font-size: 11px;
}

#calendar_div, .calendar {
  width: auto;
}
.schedule-container {
  position: relative;
  height: <?php print $row_height*(count($rows) + 1); ?>px;
  width: <?php print $grid_width; ?>px;
  background-color: #ffffcc;
  border-bottom: .3em solid #444;
}
.schedule-row {
  position: relative;
  width: 100%;
  height: <?php print $row_height; ?>px;
  clear: both;
}

.schedule-group-cell {
  position: absolute;
  width: <?php print $time_cell_width; ?>px;
  overflow: hidden;
  height: <?php print $row_height; ?>px;
  border-bottom: 1px #36648B solid;
}

.schedule-agenda-hour {
  border-left: 2px #36648B solid;
  text-align: left;
  position: absolute;
  height: <?php print $row_height; ?>px;
  padding: 2px;
}

div.calendar-span-cell-empty {
  background-color: white;
  overflow: hidden;
  position: absolute;
  border: 1px #36648B solid;

}

div.calendar-span-cell-empty:hover {
  background-color: green;

}
div.calendar-span-cell-item {
  background-color: #f7f18b;
  overflow: hidden;
  position: absolute;
  border: 1px #36648B solid;

}

div.calendar-span-cell-item:hover {
  background-color: #F8FAEA;
}

</style>
<table class="scheduleTable" cellspacing="0" cellpadding="1" border="0" width="100%">
  <tbody>
    <tr class="tableBorder">
      <td>

      <div class="schedule-container"  >

      <div class="schedule-row">

      <div class="schedule-group-cell">&nbsp;</div>

  <?php foreach ($pretty_times as $hour): ?>
  <div class="schedule-agenda-hour" style="top: 0; left: <?php print $hour['top'] + $time_cell_width; ?>px; width: <?php print $hours['span']; ?>px;" >

        <?php print $hour['hour']; ?><?php print $hour['ampm']; ?>
      </div>
  <?php endforeach; ?>
      </div>


<?php foreach($rows as $group => $items): ?>
      <div class="schedule-row">
      <div class="schedule-group-cell">
<?php print $group; ?></a>
      </div>

  <?php foreach ($items['items'] as $hour => $values): ?>

  <!-- <?php print $hour; ?> -->
  <div class="calendar-span-cell<?php print isset($values['data']) ? "-item" : "-empty"; ?> " style="height: 40px; top: 0; left: <?php print $values['total']+$time_cell_width; ?>px; width: <?php print $values['span']; ?>px; border-left: <?php print substr_compare($hour,'00:00',-5) ? 1 : 2; ?>px solid #36648B;">
<?php print isset($values) ? $values['data'] : '&nbsp;'; ?>
    </div>

<?php endforeach; ?>
</div>
<?php endforeach; ?>

</div></td></tr>

</tbody></table>

