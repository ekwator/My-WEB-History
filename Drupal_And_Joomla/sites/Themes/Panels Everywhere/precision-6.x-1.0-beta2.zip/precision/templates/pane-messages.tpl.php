<?php if (!empty($tabs)): ?>
  <?php print $tabs; ?>
<?php endif; ?>

<?php if (!empty($messages)): ?>
  <?php print $messages; ?>
<?php endif; ?>

<?php if (!empty($help)): ?>
  <?php print $help; ?>
<?php endif; ?>
