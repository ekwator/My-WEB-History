// $Id: aurora.js,v 1.1.2.1 2009/12/14 05:46:48 chrisherberte Exp $
$(document).ready(function(){ 
  $("#nav > ul").superfish({
    delay:300,
    animation:{opacity:'show',height:'show'},
    speed:'fast'
  });
});

