<?php // $Id: block-superfish.tpl.php,v 1.2 2008/09/09 13:14:22 jmburnz Exp $
/**
 * @file
 *  block.tpl.php
 *
 * Theme implementation to display the Superfish menu block.
 *
 * @see template_preprocess()
 * @see template_preprocess_block()
 */
?>
<?php print $block->content; ?>