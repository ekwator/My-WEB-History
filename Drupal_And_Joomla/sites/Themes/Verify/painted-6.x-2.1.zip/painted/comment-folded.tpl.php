<div class="comment comment-folded">
  <span class="subject"><?php print $title; if (!empty($new)): ?> <span class="new"><?php echo $new; ?></span><?php endif; ?></span><span class="credit"><?php print t(' by') .' '. $author; ?></span>
</div>