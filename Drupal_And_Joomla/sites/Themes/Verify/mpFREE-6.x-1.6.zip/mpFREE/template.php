<?php // $Id: template.php,v 1.5 2010/03/04 12:26:18 mehrpadin Exp $
function phptemplate_breadcrumb($breadcrumb) {
  if (!empty($breadcrumb)) {
    return '<div class="breadcrumb">'. implode(' › ', $breadcrumb) .'</div>';
  }
}
function phptemplate_comment_wrapper($content, $node) {
  if (!$content || $node->type == 'forum') {
    return '<div id="comments">'. $content .'</div>';
  } else {
    return '<div id="comments"><h2 class="comments">'. t('Comments') .'</h2>'. $content .'</div>';
  }
}
function phptemplate_preprocess_page(&$vars) {
  $vars['tabs2'] = menu_secondary_local_tasks();
}
function phptemplate_menu_local_tasks() {
  return menu_primary_local_tasks();
}
function phptemplate_comment_submitted($comment) {
  return t('!datetime — !username',
    array(
      '!username' => theme('username', $comment),
      '!datetime' => format_date($comment->timestamp)
    ));
}
function phptemplate_node_submitted($node) {
  return t('!datetime - !username',
    array(
      '!username' => theme('username', $node),
      '!datetime' => format_date($node->created),
    ));
}
if (is_null(theme_get_setting('colour'))) {
  global $theme_key;
  $defaults = array('colour' => 'blue');
  $settings = theme_get_settings($theme_key);
  if (module_exists('node')) {
    foreach (node_get_types() as $type => $name) {
      unset($settings['toggle_node_info_' . $type]);
    }
  }
  variable_set(
    str_replace('/', '_', 'theme_'. $theme_key .'_settings'),
    array_merge($defaults, $settings)
  );
  theme_get_setting('', TRUE);
}
drupal_add_css(path_to_theme() .'/css/'. theme_get_setting('colour') .'-skin.css', 'theme', 'all');