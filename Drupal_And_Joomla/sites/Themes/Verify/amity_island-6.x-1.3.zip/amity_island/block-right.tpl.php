<div class="sidebox-right">
  
  <h3>
    <?php print $block->subject; ?>
  </h3>
  
  <div class="sidebox-content">
    <?php print $block->content; ?>
  </div>
  
</div>
