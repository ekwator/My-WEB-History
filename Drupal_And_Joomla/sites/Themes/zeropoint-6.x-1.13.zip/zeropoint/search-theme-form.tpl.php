<div id="search" class="container-inline">
  <?php print $search_form; ?>
</div>
