<?php // $Id: block-navigation.tpl.php,v 1.1 2009/06/12 06:55:20 agileware Exp $ ?>
<?php echo art_navigation_links_worker($block->content); ?>