<?php
// $Id: box.tpl.php,v 1.3 2010/07/07 06:26:47 phasma Exp $
?>
  <div class="box">
    <?php if ($title) { ?><h2 class="title"><?php print $title; ?></h2><?php } ?>
    <div class="content"><?php print $content; ?></div>
  </div>