$(document).ready(function(){
  $('ul li').hover(function(){
    $(this).addClass('over');
  }, function() {
    $(this).removeClass('over');
  });
});